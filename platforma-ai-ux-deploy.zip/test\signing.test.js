import test from 'node:test';
import assert from 'node:assert/strict';
import { MockSigningProvider } from '../src/signing/providers/mock.js';
import { EparakstsPortalProvider } from '../src/signing/providers/eparaksts-portal.js';

test('mock sesija ved uz atsevišķu lietotāja darbības ekrānu',async()=>{
  const result=await new MockSigningProvider().start({providerSessionId:'session-1',sessionToken:'secret'});
  assert.equal(result.redirectUrl,'/mock-sign.html?session=session-1#token=secret');
});

test('mock provider neparaksta bez nepārprotama apstiprinājuma',async()=>{
  await assert.rejects(()=>new MockSigningProvider().complete({confirmed:false}),error=>error.status===400);
});

test('eParaksts adapteris bez servera konfigurācijas neveic tīkla izsaukumu',async()=>{
  await assert.rejects(()=>new EparakstsPortalProvider().start({}),error=>error.code==='EPARAKSTS_NOT_CONFIGURED');
});
