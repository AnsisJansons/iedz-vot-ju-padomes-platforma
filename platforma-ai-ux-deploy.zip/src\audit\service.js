import { db } from '../db/index.js';
export function audit({ caseId, action, actor = 'system', previousStatus = null, newStatus = null, details = null }) {
  db.prepare('INSERT INTO audit_log(case_id,action,actor,previous_status,new_status,details,created_at) VALUES(?,?,?,?,?,?,?)')
    .run(caseId, action, actor, previousStatus, newStatus, details && JSON.stringify(details), new Date().toISOString());
}
