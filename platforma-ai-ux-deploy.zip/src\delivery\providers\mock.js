import crypto from 'node:crypto'; import { config } from '../../config.js';
export class MockMailProvider {
  constructor(){this.name='mock';}
  async send({to,subject}){if(!config.allowMockDelivery)throw Object.assign(new Error('Mock nosūtīšana ir atspējota. Iestatiet ALLOW_MOCK_DELIVERY=true tikai kontrolētā testā.'),{code:'MOCK_DELIVERY_DISABLED'});return {messageId:`<mock-${crypto.randomUUID()}@local>`,recipient:to,subject};}
}
