import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { SigningProvider } from './provider.js'; import { config } from '../../config.js';

export class MockSigningProvider extends SigningProvider {
  constructor(){super('mock');if(config.nodeEnv==='production')throw new Error('Mock parakstīšanas nodrošinātājs produkcijas vidē ir aizliegts.');}
  async start({providerSessionId,sessionToken}) { return {providerSessionId,redirectUrl:`/mock-sign.html?session=${encodeURIComponent(providerSessionId)}#token=${sessionToken}`}; }
  async complete({providerSessionId,sourcePath,confirmed}) {
    if(confirmed!==true)throw Object.assign(new Error('Mock parakstam nepieciešams nepārprotams lietotāja apstiprinājums.'),{status:400});
    fs.mkdirSync(config.signedDocumentDir,{recursive:true});const target=path.join(config.signedDocumentDir,`${providerSessionId}.mock-signed.pdf`);fs.copyFileSync(sourcePath,target,fs.constants.COPYFILE_EXCL);const bytes=fs.readFileSync(target);return {signedFilePath:target,sha256:crypto.createHash('sha256').update(bytes).digest('hex'),validation:{valid:true,provider:'mock',cryptographicSignature:false,warning:'Izstrādes simulācija — fails nav kriptogrāfiski parakstīts.'}};
  }
  async cancel(){return {canceled:true};}
}
