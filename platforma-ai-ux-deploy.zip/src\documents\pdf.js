import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto';
import { PDFDocument, rgb } from 'pdf-lib'; import fontkit from '@pdf-lib/fontkit';
import { config } from '../config.js'; import { db } from '../db/index.js'; import { audit } from '../audit/service.js';

function wrap(text,font,size,width){const lines=[];for(const paragraph of text.split('\n')){if(!paragraph){lines.push('');continue;}let line='';for(const word of paragraph.split(/\s+/)){const next=line?`${line} ${word}`:word;if(font.widthOfTextAtSize(next,size)>width){if(line)lines.push(line);line=word;}else line=next;}if(line)lines.push(line);}return lines;}
export async function generatePdf(item){
  const version=db.prepare('SELECT * FROM application_versions WHERE case_id=? AND is_approved=1 ORDER BY version DESC LIMIT 1').get(item.id);
  if(!version||item.status!=='APPROVED') throw Object.assign(new Error('PDF var ģenerēt tikai apstiprinātai iesnieguma versijai.'),{status:409});
  const existing=db.prepare('SELECT * FROM generated_documents WHERE application_version_id=?').get(version.id); if(existing)return existing;
  if(!fs.existsSync(config.pdfFontPath)) throw Object.assign(new Error('Nav atrasts PDF fonts. Pārbaudiet PDF_FONT_PATH.'),{status:500});
  const pdf=await PDFDocument.create();pdf.registerFontkit(fontkit);const font=await pdf.embedFont(fs.readFileSync(config.pdfFontPath),{subset:true});const bold=font;
  const size=11,margin=58,width=595.28-margin*2;let page=pdf.addPage([595.28,841.89]),y=785;
  const line=(text,opts={})=>{for(const value of wrap(text,opts.font||font,opts.size||size,width)){if(y<65){page=pdf.addPage([595.28,841.89]);y=785;}page.drawText(value,{x:margin,y,size:opts.size||size,font:opts.font||font,color:rgb(.08,.16,.14)});y-=opts.leading||17;}};
  line('Limbažu novada pašvaldībai');line('');line(`Iesniedzējs: ${item.first_name} ${item.last_name}`);line(`E-pasts: ${item.email}`);if(item.phone)line(`Tālrunis: ${item.phone}`);line('');line(new Intl.DateTimeFormat('lv-LV').format(new Date()),{size:10});line('');
  const heading='IESNIEGUMS';page.drawText(heading,{x:(595.28-font.widthOfTextAtSize(heading,16))/2,y,size:16,font:bold});y-=32;line(version.content,{leading:18});
  const attachments=db.prepare('SELECT original_name FROM attachments WHERE case_id=? ORDER BY id').all(item.id);if(attachments.length){line('');line('Pielikumi:',{size:12});attachments.forEach((a,i)=>line(`${i+1}. ${a.original_name}`));}
  const bytes=await pdf.save();const hash=crypto.createHash('sha256').update(bytes).digest('hex');fs.mkdirSync(config.pdfDir,{recursive:true});const docVersion=db.prepare('SELECT COALESCE(MAX(version),0)+1 AS value FROM generated_documents WHERE case_id=?').get(item.id).value;const filePath=path.join(config.pdfDir,`${item.case_number}-v${docVersion}.pdf`);fs.writeFileSync(filePath,bytes,{flag:'wx'});const now=new Date().toISOString();
  const result=db.prepare('INSERT INTO generated_documents(case_id,application_version_id,version,file_path,sha256,generated_at) VALUES(?,?,?,?,?,?)').run(item.id,version.id,docVersion,filePath,hash,now);db.prepare('UPDATE cases SET pdf_path=?,updated_at=? WHERE id=?').run(filePath,now,item.id);audit({caseId:item.id,action:'PDF_GENERATED',details:{documentVersion:docVersion,sha256:hash}});return {id:Number(result.lastInsertRowid),file_path:filePath,version:docVersion,sha256:hash,generated_at:now};
}
