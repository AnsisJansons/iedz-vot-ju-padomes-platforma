# Manuālā elektroniskās parakstīšanas plūsma

Aktīvā platformas plūsma neizmanto eParaksta API. Lietotājs apstiprina iesniegumu, lejupielādē gatavo PDF, paraksta to savā eParaksta rīkā un augšupielādē `.edoc`, `.asice` vai parakstītu `.pdf`.

Platforma pārbauda faila formātu, saglabā SHA-256 hash un auditācijas ierakstu. Bez eParaksta API platforma neveic paraksta kriptogrāfisku pārbaudi, tādēļ lietotājam pirms augšupielādes jāapstiprina, ka dokuments ir parakstīts.

Iepriekš izveidotā provider/PortalSign integrācija paliek kodā vēlākam posmam. Tā pēc noklusējuma nav sasniedzama. To var aktivizēt tikai servera konfigurācijā ar `ENABLE_SIGNING_API=true`.
