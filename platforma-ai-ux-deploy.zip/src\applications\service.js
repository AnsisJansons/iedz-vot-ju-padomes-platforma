import { db } from '../db/index.js';
import { audit } from '../audit/service.js';
import { transitionCase } from '../cases/service.js';
import { deliveryInfo, responseDeadline } from '../delivery/service.js';
import { responsesForCase } from '../responses/service.js';
import { config } from '../config.js';

function clean(value) { return String(value || '').trim(); }
export function generateDraft(item) {
  const responseRequest=config.residentCouncilEmail
    ? `Lūdzu atbildi sniegt uz manu norādīto e-pasta adresi, kā arī uz iedzīvotāju padomes e-pasta adresi (${config.residentCouncilEmail}).`
    : 'Lūdzu atbildi sniegt uz manu norādīto e-pasta adresi.';
  if (clean(item.application_preparation).length >= 20) return `${clean(item.application_preparation)}\n\n${responseRequest}`;
  const place = clean(item.problem_location || item.residence);
  const situation = clean(item.question);
  const request = /\?|kad|kur|kā|vai|informāc/i.test(situation)
    ? 'Lūdzu sniegt informāciju par minēto situāciju un pašvaldības iespējamo turpmāko rīcību.'
    : 'Lūdzu izvērtēt minēto situāciju un informēt par iespējamo risinājumu.';
  const context = place ? `Situācija attiecas uz vietu: ${place}.` : '';
  return [`Vēršos Limbažu novada pašvaldībā saistībā ar tēmu “${clean(item.topic)}”.`, '', situation, '', context, request, '', responseRequest].filter((line,index,all)=>line || all[index-1] !== '').join('\n').trim();
}

function addVersion(caseId, content, actor='resident') {
  const current = db.prepare('SELECT COALESCE(MAX(version),0) AS value FROM application_versions WHERE case_id=?').get(caseId).value;
  const now=new Date().toISOString();
  const result=db.prepare('INSERT INTO application_versions(case_id,version,content,created_by,created_at) VALUES(?,?,?,?,?)').run(caseId,current+1,content,actor,now);
  audit({caseId,action:'APPLICATION_VERSION_SAVED',actor,details:{version:current+1}});
  return {id:Number(result.lastInsertRowid),version:current+1,content,createdAt:now};
}

export function createDraft(item) {
  const content=generateDraft(item); const version=addVersion(item.id,content,'system');
  transitionCase(item.id,'APPLICATION_DRAFT','system','APPLICATION_DRAFT_GENERATED'); return version;
}
export function saveDraft(item, content) {
  if(item.status!=='APPLICATION_DRAFT'&&item.status!=='APPROVED')throw Object.assign(new Error('Iesniegumu šajā statusā vairs nevar rediģēt.'),{status:409});
  content=clean(content); if(content.length<20) throw Object.assign(new Error('Iesnieguma teksts ir pārāk īss.'),{status:400});
  const version=addVersion(item.id,content);
  if(item.status==='APPROVED') transitionCase(item.id,'APPLICATION_DRAFT','resident','APPROVED_APPLICATION_REOPENED');
  return version;
}
export function getApplication(item) {
  const version=db.prepare('SELECT * FROM application_versions WHERE case_id=? ORDER BY version DESC LIMIT 1').get(item.id);
  const approvedVersion=db.prepare('SELECT * FROM application_versions WHERE case_id=? AND is_approved=1 ORDER BY version DESC LIMIT 1').get(item.id);
  const attachments=db.prepare('SELECT original_name AS originalName,size_bytes AS size FROM attachments WHERE case_id=? ORDER BY id').all(item.id);
  const signing=db.prepare('SELECT provider,status,signed_sha256 AS signedSha256,validation_result AS validationResult,completed_at AS completedAt FROM signing_sessions WHERE case_id=? ORDER BY id DESC LIMIT 1').get(item.id);
  if(signing?.validationResult){signing.validation=JSON.parse(signing.validationResult);delete signing.validationResult;}
  const followUp=db.prepare('SELECT content,status,created_at AS createdAt FROM follow_up_requests WHERE case_id=?').get(item.id);
  const sources=db.prepare('SELECT title,url,checked_at AS checkedAt FROM sources WHERE case_id=? ORDER BY id').all(item.id);
  const foundInformation=item.ai_found_information?JSON.parse(item.ai_found_information):null;
  return {caseNumber:item.case_number,status:item.status,recipient:'Limbažu novada pašvaldība',applicant:`${item.first_name} ${item.last_name}`,email:item.email,phone:item.phone,title:'IESNIEGUMS',version:version?{id:version.id,number:version.version,content:version.content,createdAt:version.created_at,isApproved:Boolean(version.is_approved)}:null,approvedVersion:approvedVersion?{id:approvedVersion.id,number:approvedVersion.version,content:approvedVersion.content,approvedAt:approvedVersion.approved_at}:null,attachments,approvedAt:item.approved_at,signing:signing||null,delivery:deliveryInfo(item.id),responseDeadline:responseDeadline(item),municipalityResponses:responsesForCase(item.id),followUp:followUp||null,analysis:foundInformation?{...foundInformation,answer:item.displayed_answer,sources}:null};
}
export function approveLatest(item) {
  const version=db.prepare('SELECT * FROM application_versions WHERE case_id=? ORDER BY version DESC LIMIT 1').get(item.id);
  if(!version) throw Object.assign(new Error('Iesnieguma projekts nav atrasts.'),{status:409});
  if(item.status!=='APPLICATION_DRAFT'&&item.status!=='WAITING_USER_APPROVAL') throw Object.assign(new Error('Iesniegumu šajā statusā nevar apstiprināt.'),{status:409});
  const now=new Date().toISOString(); db.exec('BEGIN IMMEDIATE');
  try { db.prepare('UPDATE application_versions SET is_approved=0 WHERE case_id=?').run(item.id); db.prepare('UPDATE application_versions SET is_approved=1,approved_at=? WHERE id=?').run(now,version.id); db.prepare('UPDATE cases SET final_application=?,approved_at=? WHERE id=?').run(version.content,now,item.id); if(item.status==='APPLICATION_DRAFT') transitionCase(item.id,'WAITING_USER_APPROVAL','resident','APPLICATION_FINAL_PREVIEW_CONFIRMED'); transitionCase(item.id,'APPROVED','resident','APPLICATION_APPROVED'); db.exec('COMMIT'); return {version:version.version,approvedAt:now}; }
  catch(e){db.exec('ROLLBACK');throw e;}
}

export function prepareFollowUp(item) {
  const deadline=responseDeadline(item);
  if(item.status!=='WAITING_RESPONSE' || !deadline.isOverdue) throw Object.assign(new Error('Atkārtotu pieprasījumu var sagatavot tikai pēc atbildes termiņa beigām.'),{status:409});
  const sentAt=new Date(item.sent_at).toLocaleDateString('lv-LV');
  const content=`ATKĀRTOTS PIEPRASĪJUMS\n\nLūdzu sniegt atbildi uz manu iesniegumu par tēmu “${clean(item.topic)}”, kas pašvaldībai nosūtīts ${sentAt}.\n\nLīdz šim atbilde nav saņemta. Lūdzu informēt par iesnieguma izskatīšanas gaitu un sniegt atbildi.\n\nAtsauce uz platformas lietu: ${item.case_number}.`;
  const now=new Date().toISOString();
  db.prepare("INSERT INTO follow_up_requests(case_id,content,status,created_at,updated_at) VALUES(?,?,'PREPARED',?,?) ON CONFLICT(case_id) DO UPDATE SET content=excluded.content,status='PREPARED',updated_at=excluded.updated_at").run(item.id,content,now,now);
  audit({caseId:item.id,action:'FOLLOW_UP_PREPARED',actor:'resident',details:{dueAt:deadline.dueAt}});
  return {content,status:'PREPARED',createdAt:now};
}
