import nodemailer from 'nodemailer'; import { config } from '../../config.js'; import path from 'node:path';
export class SmtpMailProvider {
  constructor(){this.name='smtp';}
  assertConfigured(){if(!config.municipalityEmail||!config.mailFrom||!process.env.SMTP_HOST||!process.env.SMTP_USER||!process.env.SMTP_PASSWORD)throw Object.assign(new Error('SMTP vai MUNICIPALITY_EMAIL nav pilnībā konfigurēts.'),{code:'MAIL_NOT_CONFIGURED'});}
  async send({to,subject,text,attachment}){this.assertConfigured();const transport=nodemailer.createTransport({host:process.env.SMTP_HOST,port:Number(process.env.SMTP_PORT||587),secure:process.env.SMTP_SECURE==='true',auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASSWORD}});const extension=path.extname(attachment.path);const filename=extension&&extension!=='.pdf'?attachment.filename.replace(/\.pdf$/i,extension):attachment.filename;const result=await transport.sendMail({from:config.mailFrom,to,subject,text,attachments:[{filename,path:attachment.path}]});return {messageId:result.messageId||null,recipient:to,subject};}
}
