# Arhitektūra

Plūsma: tīmekļa forma → API validācija → lietas serviss → SQLite transakcija (lieta, pielikumi, audits) → meklēšanas darbu rinda. Šajā prototipā meklēšanas adapteris atgriež `NO_ANSWER`, kamēr nav pieslēgts īsts pakalpojums.

Statusu pārejas kontrolē `cases/statuses.js`; vēsture glabājas `case_status_history` un `audit_log`. Katra iesnieguma saglabāšana veido jaunu `application_versions` rindu. Apstiprinātā versija tiek fiksēta, un PDF tiek veidots tikai no tās. Katrs PDF ieraksts glabā faila ceļu, SHA-256 hash un ģenerēšanas laiku.

Parakstīšanu vada `signing/service.js`, bet ārējā pakalpojuma detaļas ir izolētas `signing/providers/`. Sesija glabā provider identifikatoru, stāvokli, dokumenta sasaisti, rezultāta hash un validācijas rezultātu. Lietas statuss kļūst `SIGNED` tikai pēc provider rezultāta validācijas; atcelta sesija atstāj lietu `WAITING_SIGNATURE`. Izstrādes mock ir skaidri marķēts kā nekriptogrāfisks un nevar startēt ar `NODE_ENV=production`.

Nosūtīšanu vada `delivery/service.js`. Tas no servera konfigurācijas izmanto vienīgi `MUNICIPALITY_EMAIL`, sasaista piegādi ar parakstīšanas sesiju un bloķē atkārtotu veiksmīgas piegādes mēģinājumu. `outbound_deliveries` glabā saņēmēju, laiku, message ID, dokumenta identifikatoru, mēģinājumu skaitu un kļūdu. E-pasta neveiksme neatceļ derīgu parakstu un nemaina lietu uz `SENT_TO_MUNICIPALITY`.

`responses/service.js` pieņem uzticama e-pasta savienotāja webhook. Atbilde tiek piesaistīta tikai ar nosūtītā message ID thread informāciju vai lietas numuru; pretējā gadījumā tā tiek noraidīta manuālai izskatīšanai. Oriģinālais teksts un pielikumi tiek glabāti atsevišķi no iespējamā vēlākā AI kopsavilkuma. Atbildes termiņš nav juridiska konstante: tas ir konfigurējams katrai lietai vai ar apstiprinātu noklusējuma konfigurāciju.

Personīgais kabinets izmanto `user_accounts` ar hash veidā glabātu piekļuves marķieri; e-pasta adrese viena pati nekad netiek izmantota kā piekļuves pierādījums. Administratora skats izmanto atsevišķu servera marķieri un ir lasīšanas/pārvaldības skats, nevis darbību virs apstiprināta vai parakstīta dokumenta kanāls.

Nākamie drošie soļi: pilna autentifikācija un piekļuves lomas; CSRF/rate-limit/ļaunprogrammatūras pārbaude; uzticamu domēnu indeksētājs; AI atbilde tikai no saglabātiem avotiem; sertificēta eParaksta plūsma; e-pasta piegāde tikai uz `MUNICIPALITY_EMAIL`; ienākošo atbilžu sasaistīšana un administratora panelis.
