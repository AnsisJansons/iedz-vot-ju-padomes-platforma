import test from 'node:test'; import assert from 'node:assert/strict'; import { validateCase } from '../src/api/validation.js'; import { analyzeQuestion } from '../src/search/index.js';
test('validē obligātos laukus',()=>{const errors=validateCase({});assert.deepEqual(Object.keys(errors).sort(),['consent','email','firstName','lastName','question','topic'].sort());});
test('pieņem korektu jautājumu',()=>assert.deepEqual(validateCase({firstName:'Anna',lastName:'Bērziņa',email:'anna@example.lv',topic:'Ceļi un ielas',question:'Kad salabos ceļu?',consent:'on'}),{}));
test('meklēšanas konteksts vienmēr ir Limbažu novads',()=>assert.equal(analyzeQuestion({topic:'Vide',question:'Kur ziņot par atkritumiem?',residence:'Ainaži'}).municipality,'Limbažu novads'));
