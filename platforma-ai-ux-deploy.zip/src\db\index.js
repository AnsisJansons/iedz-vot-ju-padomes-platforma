import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { config } from '../config.js';

fs.mkdirSync(path.dirname(config.databasePath), { recursive: true });
export const db = new DatabaseSync(config.databasePath);
db.exec(fs.readFileSync(new URL('./schema.sql', import.meta.url), 'utf8'));

function ensureColumn(table, name, definition) {
  const columns=db.prepare(`PRAGMA table_info(${table})`).all();
  if(!columns.some(column=>column.name===name)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${definition}`);
}
ensureColumn('cases','access_token_hash',"TEXT NOT NULL DEFAULT ''");
ensureColumn('cases','approved_at','TEXT');
ensureColumn('cases','response_due_at','TEXT');
ensureColumn('cases','response_received_at','TEXT');
ensureColumn('cases','user_account_id','INTEGER REFERENCES user_accounts(id)');
ensureColumn('cases','resource_text','TEXT');
db.exec('CREATE INDEX IF NOT EXISTS idx_cases_user_account ON cases(user_account_id)');
ensureColumn('application_versions','approved_at','TEXT');
ensureColumn('application_versions','is_approved','INTEGER NOT NULL DEFAULT 0');
