export const TOPICS = Object.freeze(['Ceļi un ielas','Ielu apgaismojums','Sabiedriskais transports','Atkritumi un vide','Pašvaldības īpašumi','Teritorijas plānošana','Būvniecība','Sociālie jautājumi','Izglītība','Kultūra','Sports','Drošība','Uzņēmējdarbība','Pašvaldības pakalpojumi','Citi jautājumi']);
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_RESOURCE_TEXT_CHARACTERS = 12000;
export function validateCase(data) {
  const errors = {};
  if (!data.firstName?.trim()) errors.firstName = 'Ievadiet vārdu.';
  if (!data.lastName?.trim()) errors.lastName = 'Ievadiet uzvārdu.';
  if (!emailPattern.test(data.email || '')) errors.email = 'Ievadiet derīgu e-pasta adresi.';
  if (!TOPICS.includes(data.topic)) errors.topic = 'Izvēlieties tēmu.';
  if (!data.question?.trim()) errors.question = 'Aprakstiet jautājumu vai problēmu.';
  if ((data.resourceText || '').length > MAX_RESOURCE_TEXT_CHARACTERS) errors.resourceText = `Resursa teksts nedrīkst pārsniegt ${MAX_RESOURCE_TEXT_CHARACTERS} rakstzīmes.`;
  if (data.consent !== 'true' && data.consent !== 'on') errors.consent = 'Nepieciešama piekrišana personas datu apstrādei.';
  return errors;
}
