import crypto from 'node:crypto';

const buckets=new Map();
export function clientIp(req){return String(req.headers['x-forwarded-for']||req.socket.remoteAddress||'unknown').split(',')[0].trim();}
export function allowRequest(req,{limit,windowMs}){const key=`${clientIp(req)}:${req.url?.split('?')[0]||''}`,now=Date.now();const state=buckets.get(key);if(!state||state.resetAt<=now){buckets.set(key,{count:1,resetAt:now+windowMs});return true;}state.count+=1;return state.count<=limit;}
export function securityHeaders(res){res.setHeader('x-content-type-options','nosniff');res.setHeader('x-frame-options','DENY');res.setHeader('referrer-policy','same-origin');res.setHeader('permissions-policy','camera=(), microphone=(), geolocation=()');res.setHeader('cross-origin-opener-policy','same-origin');res.setHeader('content-security-policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");res.setHeader('cache-control','no-store');}
export function safeRequestId(){return crypto.randomUUID();}
