export const sourcePriority = Object.freeze([
  'limbazunovads.lv official information', 'municipal documents', 'council decisions and minutes',
  'binding regulations', 'budget and development plans', 'municipal institutions', 'official state resources', 'likumi.lv'
]);

export class DisabledSearchProvider {
  async search(context) {
    return { answer: null, sources: [], confidence: 0, missing_information: ['Meklēšanas pakalpojums vēl nav konfigurēts.'], recommended_next_step: 'Piedāvāt sagatavot iesniegumu.', context };
  }
}

export function analyzeQuestion({ topic, question, residence, problemLocation }) {
  return { topic, issue: question.trim(), place: problemLocation || residence || null, municipality: 'Limbažu novads', informationType: 'official_public_information', keywords: [topic, 'Limbažu novads', ...question.split(/\s+/).filter(w => w.length > 5).slice(0, 5)] };
}
