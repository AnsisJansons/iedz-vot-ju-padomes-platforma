import { SigningProvider } from './provider.js'; import { config } from '../../config.js';

// Adaptera robeža LVRTC PortalSign plūsmai. Reālā tīkla aktivizēšana paredzēta tikai pēc
// pakalpojuma līguma, akreditācijas datu un HTTPS atgriešanās adreses konfigurēšanas.
export class EparakstsPortalProvider extends SigningProvider {
  constructor(){super('eparaksts_portal');}
  assertConfigured(){if(!config.eparaksts.username||!config.eparaksts.password||!config.publicBaseUrl.startsWith('https://'))throw Object.assign(new Error('eParaksts PortalSign nav pilnībā konfigurēts.'),{status:503,code:'EPARAKSTS_NOT_CONFIGURED'});}
  async start(){this.assertConfigured();throw Object.assign(new Error('PortalSign tīkla adapteris jāaktivizē pēc LVRTC piekļuves datu saņemšanas.'),{status:503,code:'EPARAKSTS_ACTIVATION_REQUIRED'});}
  async complete(){this.assertConfigured();throw Object.assign(new Error('PortalSign rezultāta saņemšana vēl nav aktivizēta.'),{status:503,code:'EPARAKSTS_ACTIVATION_REQUIRED'});}
  async cancel(){return {canceled:true};}
}
