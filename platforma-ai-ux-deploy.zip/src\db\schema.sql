PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS cases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  case_number TEXT UNIQUE, access_token_hash TEXT NOT NULL, user_account_id INTEGER REFERENCES user_accounts(id),
  first_name TEXT NOT NULL, last_name TEXT NOT NULL, email TEXT NOT NULL,
  phone TEXT, residence TEXT, topic TEXT NOT NULL, question TEXT NOT NULL,
  problem_location TEXT, resource_text TEXT, consent_personal_data INTEGER NOT NULL CHECK(consent_personal_data = 1),
  status TEXT NOT NULL DEFAULT 'NEW', ai_found_information TEXT, ai_answer TEXT,
  displayed_answer TEXT, application_preparation TEXT, final_application TEXT,
  pdf_path TEXT, signing_status TEXT, sending_status TEXT, sent_at TEXT,
  municipality_response TEXT, approved_at TEXT, response_due_at TEXT, response_received_at TEXT, closed_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS user_accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE,
  access_token_hash TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attachments (
  id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id),
  original_name TEXT NOT NULL, stored_name TEXT NOT NULL, mime_type TEXT, size_bytes INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sources (
  id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id),
  title TEXT NOT NULL, url TEXT NOT NULL, published_at TEXT, summary TEXT NOT NULL,
  trust_level TEXT NOT NULL, checked_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS application_versions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id),
  version INTEGER NOT NULL, content TEXT NOT NULL, created_by TEXT NOT NULL, created_at TEXT NOT NULL,
  approved_at TEXT, is_approved INTEGER NOT NULL DEFAULT 0,
  UNIQUE(case_id, version)
);
CREATE TABLE IF NOT EXISTS generated_documents (
  id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id),
  application_version_id INTEGER NOT NULL REFERENCES application_versions(id), version INTEGER NOT NULL,
  file_path TEXT NOT NULL, sha256 TEXT NOT NULL, generated_at TEXT NOT NULL,
  UNIQUE(case_id, version)
);
CREATE TABLE IF NOT EXISTS signing_sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id),
  document_id INTEGER NOT NULL REFERENCES generated_documents(id), provider TEXT NOT NULL,
  provider_session_id TEXT NOT NULL UNIQUE, access_token_hash TEXT NOT NULL,
  status TEXT NOT NULL, redirect_url TEXT, signed_file_path TEXT, signed_sha256 TEXT,
  validation_result TEXT, error_code TEXT, user_action_at TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL, completed_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_signing_case ON signing_sessions(case_id);
CREATE TABLE IF NOT EXISTS outbound_deliveries (
  id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id),
  signed_document_id INTEGER NOT NULL REFERENCES signing_sessions(id),
  recipient TEXT NOT NULL, subject TEXT NOT NULL, status TEXT NOT NULL,
  attempt_count INTEGER NOT NULL DEFAULT 0, message_id TEXT, provider TEXT NOT NULL,
  error_code TEXT, error_message TEXT, sent_at TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
  UNIQUE(case_id, signed_document_id)
);
CREATE TABLE IF NOT EXISTS municipality_responses (
  id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id),
  source_message_id TEXT, in_reply_to TEXT, email_subject TEXT, sender TEXT,
  original_text TEXT NOT NULL, received_at TEXT NOT NULL, summary TEXT,
  match_method TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS municipality_response_attachments (
  id INTEGER PRIMARY KEY AUTOINCREMENT, response_id INTEGER NOT NULL REFERENCES municipality_responses(id),
  original_name TEXT NOT NULL, stored_name TEXT NOT NULL, mime_type TEXT, size_bytes INTEGER NOT NULL,
  sha256 TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_response_case ON municipality_responses(case_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_response_message ON municipality_responses(source_message_id) WHERE source_message_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS case_status_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER NOT NULL REFERENCES cases(id),
  previous_status TEXT, new_status TEXT NOT NULL, actor TEXT NOT NULL, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT, case_id INTEGER REFERENCES cases(id), action TEXT NOT NULL,
  actor TEXT NOT NULL, previous_status TEXT, new_status TEXT, details TEXT, created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cases_number ON cases(case_number);
CREATE INDEX IF NOT EXISTS idx_audit_case ON audit_log(case_id);
CREATE TABLE IF NOT EXISTS follow_up_requests (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  case_id INTEGER NOT NULL REFERENCES cases(id),
  content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PREPARED',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  UNIQUE(case_id)
);
