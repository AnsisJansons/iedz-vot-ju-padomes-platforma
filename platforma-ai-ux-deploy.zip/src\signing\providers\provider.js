export class SigningProvider {
  constructor(name) { this.name=name; }
  async start() { throw new Error('SigningProvider.start nav implementēts'); }
  async complete() { throw new Error('SigningProvider.complete nav implementēts'); }
  async cancel() { throw new Error('SigningProvider.cancel nav implementēts'); }
}
