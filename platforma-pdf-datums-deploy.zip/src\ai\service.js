import OpenAI from 'openai';
import { config } from '../config.js';
import { db } from '../db/index.js';
import { audit } from '../audit/service.js';
import { transitionCase } from '../cases/service.js';

const analysisSchema = {
  type: 'object', additionalProperties: false,
  properties: {
    outcome: { type: 'string', enum: ['ANSWER_FOUND', 'PARTIAL_ANSWER', 'NO_ANSWER'] },
    answerSummary: { type: 'string' },
    keyPoints: { type: 'array', items: { type: 'string' } },
    nextStep: { type: 'string' },
    explanation: { type: 'string' },
    shouldOfferApplication: { type: 'boolean' },
    applicationDraft: { type: 'string' }
  },
  required: ['outcome', 'answerSummary', 'keyPoints', 'nextStep', 'explanation', 'shouldOfferApplication', 'applicationDraft']
};

function clean(value) { return String(value || '').trim(); }

function collectSources(value, sources = [], seen = new Set()) {
  if (!value || typeof value !== 'object') return sources;
  if (Array.isArray(value)) { for (const item of value) collectSources(item, sources, seen); return sources; }
  if (typeof value.url === 'string' && /^https:\/\//.test(value.url) && !seen.has(value.url)) {
    seen.add(value.url);
    sources.push({ title: clean(value.title || value.name || 'Publisks avots'), url: value.url });
  }
  for (const item of Object.values(value)) collectSources(item, sources, seen);
  return sources;
}

function parseAnalysis(response) {
  try { return JSON.parse(response.output_text); }
  catch { throw Object.assign(new Error('AI atgrieza nederīgu atbildes formātu.'), { status: 502, code: 'AI_INVALID_RESPONSE' }); }
}

function inputFor(item) {
  return JSON.stringify({
    municipality: 'Limbažu novads',
    topic: clean(item.topic), question: clean(item.question),
    residenceOrSettlement: clean(item.residence), problemLocation: clean(item.problem_location),
    initialAdditionalDetails: clean(item.resource_text) || null,
    clarifications: db.prepare('SELECT content FROM case_clarifications WHERE case_id=? ORDER BY id').all(item.id).map(row => clean(row.content)).filter(Boolean)
  });
}

export function aiIsAvailable() { return config.aiProvider === 'openai' && Boolean(config.openaiApiKey); }

export async function analyzeCaseWithAi(item) {
  if (!aiIsAvailable()) throw Object.assign(new Error('AI meklēšana pašlaik nav ieslēgta.'), { status: 503, code: 'AI_DISABLED' });
  if (!['NEW', 'APPLICATION_OFFERED', 'ERROR'].includes(item.status)) throw Object.assign(new Error('Šīs lietas AI izvērtējumu šajā posmā vairs nevar pārskatīt.'), { status: 409 });
  transitionCase(item.id, 'SEARCHING', 'system', 'AI_ANALYSIS_STARTED');
  try {
    const client = new OpenAI({ apiKey: config.openaiApiKey });
    const response = await client.responses.create({
      model: config.openaiModel,
      store: false,
      tools: config.aiWebSearch ? [{ type: 'web_search' }] : [],
      include: config.aiWebSearch ? ['web_search_call.action.sources'] : [],
      instructions: `Tu esi Latvijas pašvaldības informācijas palīgs. Atbildi latviešu valodā. Izmanto tikai publisku informāciju un lietotāja iesniegto resursa tekstu. Meklējot tīmeklī, priekšroku dod Limbažu novada pašvaldības vietnei, likumi.lv un Latvija.gov.lv. Neizdomā faktus, datumus, kontaktus vai tiesību normas. Ja avots nav pietiekams, skaidri pasaki to. Nesniedz juridisku atzinumu un neapgalvo juridisku pareizību. Neatkārto vai neprasi personas datus. Atbildi strukturē: answerSummary ir viens īss secinājums (ne vairāk kā 3 teikumi), keyPoints ir 2–5 īsi konkrēti punkti, nextStep ir viens skaidrs ieteikums. Nelieto Markdown saites vai avotu sarakstu šajos laukos. shouldOfferApplication ir true tikai tad, ja informācijas nepietiek, nepieciešama pašvaldības rīcība vai iedzīvotājam jāiesniedz oficiāls pieprasījums; citādi false. Laukā applicationDraft izveido neitrālu, cieņpilnu iesnieguma pamattekstu, saglabājot tikai lietotāja minētos faktus. Tas nedrīkst saturēt adresātu, iesniedzēja vārdu, parakstu vai teikumu par atbildes saņemšanu un tam jābūt pārskatāmam cilvēkam pirms izmantošanas.`,
      input: inputFor(item),
      text: { format: { type: 'json_schema', name: 'municipality_answer', strict: true, schema: analysisSchema } }
    });
    const analysis = parseAnalysis(response);
    const sources = collectSources(response);
    const now = new Date().toISOString();
    db.exec('BEGIN IMMEDIATE');
    try {
      db.prepare('DELETE FROM sources WHERE case_id=?').run(item.id);
      const addSource = db.prepare('INSERT INTO sources(case_id,title,url,summary,trust_level,checked_at) VALUES(?,?,?,?,?,?)');
      for (const source of sources) addSource.run(item.id, source.title.slice(0, 500), source.url, '', 'AI_WEB_SEARCH', now);
      db.prepare('UPDATE cases SET ai_found_information=?,ai_answer=?,displayed_answer=?,application_preparation=?,updated_at=? WHERE id=?')
        .run(JSON.stringify({ outcome: analysis.outcome, explanation: analysis.explanation, keyPoints: analysis.keyPoints, nextStep: analysis.nextStep, shouldOfferApplication: analysis.shouldOfferApplication, sourceCount: sources.length }), analysis.answerSummary, analysis.answerSummary, analysis.applicationDraft, now, item.id);
      db.exec('COMMIT');
    } catch (error) { db.exec('ROLLBACK'); throw error; }
    transitionCase(item.id, analysis.outcome, 'system', 'AI_ANALYSIS_COMPLETED');
    transitionCase(item.id, 'APPLICATION_OFFERED', 'system', 'APPLICATION_OFFERED_AFTER_AI');
    audit({ caseId: item.id, action: 'AI_SOURCES_STORED', actor: 'system', details: { sourceCount: sources.length, webSearch: config.aiWebSearch } });
    return { outcome: analysis.outcome, answer: analysis.answerSummary, keyPoints: analysis.keyPoints, nextStep: analysis.nextStep, explanation: analysis.explanation, sources, shouldOfferApplication: true };
  } catch (error) {
    const current = db.prepare('SELECT status FROM cases WHERE id=?').get(item.id);
    if (current?.status === 'SEARCHING') transitionCase(item.id, 'ERROR', 'system', 'AI_ANALYSIS_FAILED');
    throw error;
  }
}
