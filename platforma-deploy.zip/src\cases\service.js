import { db } from '../db/index.js';
import { audit } from '../audit/service.js';
import crypto from 'node:crypto';
import { allowedTransitions } from './statuses.js';
import { statusLabel } from './presentation.js';

function makeCaseNumber(id, date = new Date()) { return `LIM-${date.getFullYear()}-${String(id).padStart(6, '0')}`; }

export function createCase(input, attachments = []) {
  const now = new Date().toISOString();
  const accessToken = crypto.randomBytes(24).toString('base64url');
  const tokenHash = crypto.createHash('sha256').update(accessToken).digest('hex');
  db.exec('BEGIN IMMEDIATE');
  try {
    const normalizedEmail=input.email.trim().toLowerCase();let account=null,cabinetAccessToken=input.cabinetToken||null;
    if(cabinetAccessToken){const candidate=db.prepare('SELECT * FROM user_accounts WHERE email=?').get(normalizedEmail);if(candidate&&crypto.timingSafeEqual(Buffer.from(candidate.access_token_hash,'hex'),crypto.createHash('sha256').update(cabinetAccessToken).digest()))account=candidate;}
    if(!account){account=db.prepare('SELECT * FROM user_accounts WHERE email=?').get(normalizedEmail);if(account)throw Object.assign(new Error('Šai e-pasta adresei jau ir personīgais kabinets. Atveriet to ar iepriekš saglabāto drošo saiti.'),{status:409,code:'CABINET_ACCESS_REQUIRED'});cabinetAccessToken=crypto.randomBytes(32).toString('base64url');const accountResult=db.prepare('INSERT INTO user_accounts(email,access_token_hash,created_at,updated_at) VALUES(?,?,?,?)').run(normalizedEmail,crypto.createHash('sha256').update(cabinetAccessToken).digest('hex'),now,now);account={id:Number(accountResult.lastInsertRowid)};}
    const result = db.prepare(`INSERT INTO cases(access_token_hash,user_account_id,first_name,last_name,email,phone,residence,topic,question,problem_location,consent_personal_data,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,1,'NEW',?,?)`)
      .run(tokenHash, account.id, input.firstName, input.lastName, normalizedEmail, input.phone || null, input.residence || null, input.topic, input.question, input.problemLocation || null, now, now);
    const id = Number(result.lastInsertRowid);
    const caseNumber = makeCaseNumber(id);
    db.prepare('UPDATE cases SET case_number=? WHERE id=?').run(caseNumber, id);
    const addAttachment = db.prepare('INSERT INTO attachments(case_id,original_name,stored_name,mime_type,size_bytes,created_at) VALUES(?,?,?,?,?,?)');
    for (const file of attachments) addAttachment.run(id, file.originalName, file.storedName, file.mimeType, file.size, now);
    db.prepare('INSERT INTO case_status_history(case_id,previous_status,new_status,actor,created_at) VALUES(?,NULL,?,?,?)').run(id, 'NEW', 'resident', now);
    audit({ caseId: id, action: 'CASE_CREATED', actor: 'resident', newStatus: 'NEW', details: { attachmentCount: attachments.length } });
    db.exec('COMMIT');
    return { id, caseNumber, accessToken, cabinetAccessToken, status: 'NEW' };
  } catch (error) { db.exec('ROLLBACK'); throw error; }
}

export function getPublicCase(caseNumber) {
  return db.prepare('SELECT case_number AS caseNumber, topic, status, created_at AS createdAt, updated_at AS updatedAt, displayed_answer AS displayedAnswer FROM cases WHERE case_number=?').get(caseNumber);
}

export function authorizeCabinet(token){if(!token)return null;const tokenHash=crypto.createHash('sha256').update(token).digest();const accounts=db.prepare('SELECT * FROM user_accounts').all();return accounts.find(account=>{const expected=Buffer.from(account.access_token_hash,'hex');return expected.length===tokenHash.length&&crypto.timingSafeEqual(expected,tokenHash);})||null;}

export function cabinetCases(accountId){return db.prepare('SELECT case_number AS caseNumber,topic,question,created_at AS createdAt,status,ai_answer AS aiAnswer,displayed_answer AS displayedAnswer,sent_at AS sentAt,signing_status AS signingStatus FROM cases WHERE user_account_id=? ORDER BY created_at DESC').all(accountId).map(item=>({...item,statusLabel:statusLabel(item.status)}));}

export function authorizeCase(caseNumber, token) {
  if (!token) return null;
  const item = db.prepare('SELECT * FROM cases WHERE case_number=?').get(caseNumber);
  if (!item) return null;
  const actual = crypto.createHash('sha256').update(token).digest();
  const expected = Buffer.from(item.access_token_hash, 'hex');
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected) ? item : null;
}

export function transitionCase(caseId, newStatus, actor, action) {
  const item = db.prepare('SELECT status FROM cases WHERE id=?').get(caseId);
  if (!item || !(allowedTransitions[item.status] || []).includes(newStatus)) throw Object.assign(new Error(`Neatļauta statusa pāreja: ${item?.status} → ${newStatus}`), { status: 409 });
  const now = new Date().toISOString();
  db.prepare('UPDATE cases SET status=?,updated_at=? WHERE id=?').run(newStatus, now, caseId);
  db.prepare('INSERT INTO case_status_history(case_id,previous_status,new_status,actor,created_at) VALUES(?,?,?,?,?)').run(caseId,item.status,newStatus,actor,now);
  audit({caseId,action,actor,previousStatus:item.status,newStatus});
}
