import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { createCase, getPublicCase, authorizeCase, authorizeCabinet } from '../cases/service.js';
import { validateCase } from './validation.js';
import { createDraft, saveDraft, getApplication, approveLatest, prepareFollowUp } from '../applications/service.js';
import { generatePdf } from '../documents/pdf.js';
import { db } from '../db/index.js';
import { startSigning, authorizeSigningSession, signingSessionView, completeSigning, cancelSigning, uploadManuallySigned } from '../signing/service.js';
import { attemptDelivery, setResponseDeadline, overdueCases, deliveryInfo } from '../delivery/service.js';
import { ingestMunicipalityResponse } from '../responses/service.js';
import { cabinetDetails } from '../cabinet/service.js';
import { listCases, adminCaseTimeline } from '../admin/service.js';

function json(res, status, value) { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(value)); }
async function body(req) { const chunks=[]; let size=0; for await (const c of req) { size += c.length; if (size > config.maxUploadBytes) throw Object.assign(new Error('Pieprasījums ir pārāk liels.'), { status: 413 }); chunks.push(c); } return Buffer.concat(chunks); }
async function jsonBody(req) { try { return JSON.parse((await body(req)).toString('utf8') || '{}'); } catch { throw Object.assign(new Error('Nederīgs JSON.'), { status: 400 }); } }
function bearer(req){return req.headers.authorization?.replace(/^Bearer\s+/i,'')||'';}
function isAdmin(req){return Boolean(config.adminApiToken)&&bearer(req)===config.adminApiToken;}
function isInboundTrusted(req){return Boolean(config.inboundWebhookSecret)&&bearer(req)===config.inboundWebhookSecret;}
function parseMultipart(buffer, boundary) {
  const values = {}; const files = []; const marker = Buffer.from(`--${boundary}`); let start = buffer.indexOf(marker);
  while (start >= 0) { const next = buffer.indexOf(marker, start + marker.length); if (next < 0) break; const part = buffer.subarray(start + marker.length + 2, next - 2); const split=part.indexOf('\r\n\r\n'); if (split > 0) { const headers=part.subarray(0,split).toString(); const content=part.subarray(split+4); const name=/name="([^"]+)"/.exec(headers)?.[1]; const filename=/filename="([^"]*)"/.exec(headers)?.[1]; if (name && filename) files.push({ field:name, originalName:path.basename(filename), mimeType:/Content-Type:\s*([^\r\n]+)/i.exec(headers)?.[1] || 'application/octet-stream', content }); else if (name) values[name]=content.toString('utf8'); } start=next; }
  return { values, files };
}
const allowedUploads=Object.freeze({'.pdf':['application/pdf'],'.png':['image/png'],'.jpg':['image/jpeg'],'.jpeg':['image/jpeg'],'.txt':['text/plain']});
function validateUpload(file){const extension=path.extname(file.originalName).toLowerCase();if(!allowedUploads[extension]||!allowedUploads[extension].includes(file.mimeType.toLowerCase()))throw Object.assign(new Error('Atļauti tikai PDF, PNG, JPG vai TXT pielikumi.'),{status:400});const bytes=file.content;if(extension==='.pdf'&&!bytes.subarray(0,5).equals(Buffer.from('%PDF-')))throw Object.assign(new Error('PDF pielikuma saturs nav derīgs.'),{status:400});if(extension==='.png'&&!bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))throw Object.assign(new Error('PNG pielikuma saturs nav derīgs.'),{status:400});if((extension==='.jpg'||extension==='.jpeg')&&!(bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff))throw Object.assign(new Error('JPG pielikuma saturs nav derīgs.'),{status:400});if(extension==='.txt'&&bytes.includes(0))throw Object.assign(new Error('TXT pielikums nedrīkst būt binārs.'),{status:400});}
export async function handleApi(req, res, url) {
  if (req.method === 'GET' && url.pathname === '/api/health') return json(res, 200, { ok: true });
  if(req.method==='GET'&&url.pathname==='/api/cabinet'){const account=authorizeCabinet(bearer(req)||url.searchParams.get('token'));if(!account)return json(res,403,{error:'Nav piekļuves personīgajam kabinetam.'});return json(res,200,{email:account.email,cases:cabinetDetails(account.id)});}
  const responseAttachmentMatch=/^\/api\/responses\/(\d+)\/attachments\/(\d+)$/.exec(url.pathname);
  if(req.method==='GET'&&responseAttachmentMatch){const row=db.prepare('SELECT a.*,c.case_number FROM municipality_response_attachments a JOIN municipality_responses r ON r.id=a.response_id JOIN cases c ON c.id=r.case_id WHERE a.id=? AND r.id=?').get(Number(responseAttachmentMatch[2]),Number(responseAttachmentMatch[1]));if(!row||!authorizeCase(row.case_number,bearer(req)||url.searchParams.get('token')))return json(res,403,{error:'Nav piekļuves pielikumam.'});const filePath=path.join(config.uploadDir,'municipality-responses',row.stored_name);res.writeHead(200,{'content-type':row.mime_type||'application/octet-stream','content-disposition':`attachment; filename="${row.original_name.replace(/["\\]/g,'_')}"`,'x-content-type-options':'nosniff'});fs.createReadStream(filePath).on('error',()=>{if(!res.headersSent)json(res,404,{error:'Pielikums nav atrasts.'});else res.end();}).pipe(res);return;}
  if(req.method==='POST'&&url.pathname==='/api/inbound/municipality'){if(!isInboundTrusted(req))return json(res,403,{error:'Nederīga inbound autentifikācija.'});return json(res,201,ingestMunicipalityResponse(await jsonBody(req)));}
  if(req.method==='GET'&&url.pathname==='/api/admin/cases'){if(!isAdmin(req))return json(res,403,{error:'Nepieciešama administratora piekļuve.'});return json(res,200,{items:listCases(Object.fromEntries(url.searchParams))});}
  const adminTimelineMatch=/^\/api\/admin\/cases\/([^/]+)\/timeline$/.exec(url.pathname);
  if(req.method==='GET'&&adminTimelineMatch){if(!isAdmin(req))return json(res,403,{error:'Nepieciešama administratora piekļuve.'});const timeline=adminCaseTimeline(decodeURIComponent(adminTimelineMatch[1]));return timeline?json(res,200,{timeline}):json(res,404,{error:'Lieta nav atrasta.'});}
  if(url.pathname==='/api/admin/response-overdue'){if(!isAdmin(req))return json(res,403,{error:'Nepieciešama administratora piekļuve.'});if(req.method==='GET')return json(res,200,{items:overdueCases()});}
  const adminMatch=/^\/api\/admin\/cases\/([^/]+)\/(retry-delivery|deadline|delivery)$/.exec(url.pathname);
  if(adminMatch){if(!isAdmin(req))return json(res,403,{error:'Nepieciešama administratora piekļuve.'});const item=db.prepare('SELECT * FROM cases WHERE case_number=?').get(decodeURIComponent(adminMatch[1]));if(!item)return json(res,404,{error:'Lieta nav atrasta.'});if(req.method==='GET'&&adminMatch[2]==='delivery')return json(res,200,{delivery:deliveryInfo(item.id)});if(req.method==='POST'&&adminMatch[2]==='retry-delivery')return json(res,200,await attemptDelivery(item,{retry:true,actor:'admin'}));if(req.method==='POST'&&adminMatch[2]==='deadline'){const input=await jsonBody(req);setResponseDeadline(item,input.dueAt,'admin');return json(res,200,{dueAt:new Date(input.dueAt).toISOString()});}}
  const signingMatch=/^\/api\/signing\/sessions\/([^/]+)(?:\/(complete|cancel))?$/.exec(url.pathname);
  if(signingMatch&&!config.signingApiEnabled)return json(res,404,{error:'API parakstīšana pašlaik nav aktīva.'});
  if(signingMatch){const token=req.headers.authorization?.replace(/^Bearer\s+/i,'')||url.searchParams.get('token'),session=authorizeSigningSession(decodeURIComponent(signingMatch[1]),token);if(!session)return json(res,403,{error:'Nav piekļuves parakstīšanas sesijai.'});if(req.method==='GET'&&!signingMatch[2])return json(res,200,signingSessionView(session));if(req.method==='POST'&&signingMatch[2]==='complete'){const input=await jsonBody(req);return json(res,200,await completeSigning(session,input.confirm));}if(req.method==='POST'&&signingMatch[2]==='cancel')return json(res,200,await cancelSigning(session));}
  const applicationMatch=/^\/api\/cases\/([^/]+)\/application(?:\/(approve|pdf|signing|signed-upload))?$/.exec(url.pathname);
  if (applicationMatch) {
    const caseNumber=decodeURIComponent(applicationMatch[1]);
    const token=req.headers.authorization?.replace(/^Bearer\s+/i,'') || url.searchParams.get('token');
    let item=authorizeCase(caseNumber,token);
    if (!item) return json(res,403,{error:'Nav piekļuves šai lietai.'});
    if (req.method==='GET' && !applicationMatch[2]) return json(res,200,getApplication(item));
    if (req.method==='POST' && !applicationMatch[2]) {
      const current=getApplication(item);
      if (!current.version) { createDraft(item); item=authorizeCase(caseNumber,token); return json(res,201,{application:getApplication(item)}); }
      const input=await jsonBody(req); saveDraft(item,input.content); item=authorizeCase(caseNumber,token); return json(res,201,{application:getApplication(item)});
    }
    if (req.method==='POST' && applicationMatch[2]==='approve') { const input=await jsonBody(req); if(input.confirm!==true)return json(res,400,{error:'Nepieciešams skaidrs apstiprinājums.'}); return json(res,200,approveLatest(item)); }
    if (req.method==='POST' && applicationMatch[2]==='pdf') { const document=await generatePdf(item); return json(res,201,{version:document.version,sha256:document.sha256,generatedAt:document.generated_at,downloadUrl:`/api/documents/${document.id}?token=${encodeURIComponent(token)}`}); }
    if (req.method==='POST' && applicationMatch[2]==='signing') { if(!config.signingApiEnabled)return json(res,404,{error:'API parakstīšana pašlaik nav aktīva.'});const input=await jsonBody(req); return json(res,201,await startSigning(item,input.confirmStart)); }
    if(req.method==='POST'&&applicationMatch[2]==='signed-upload'){const match=/multipart\/form-data;\s*boundary=(?:"([^"]+)"|([^;]+))/i.exec(req.headers['content-type']||'');if(!match)return json(res,415,{error:'Nepieciešams multipart/form-data.'});const parsed=parseMultipart(await body(req),match[1]||match[2]);if(parsed.files.length!==1)return json(res,400,{error:'Pievienojiet vienu parakstīto dokumentu.'});return json(res,201,await uploadManuallySigned(item,parsed.files[0],parsed.values.confirm==='true'));}
  }
  const followUpMatch=/^\/api\/cases\/([^/]+)\/follow-up$/.exec(url.pathname);
  if(req.method==='POST'&&followUpMatch){const caseNumber=decodeURIComponent(followUpMatch[1]);const item=authorizeCase(caseNumber,bearer(req)||url.searchParams.get('token'));if(!item)return json(res,403,{error:'Nav piekļuves šai lietai.'});return json(res,201,{followUp:prepareFollowUp(item)});}
  const documentMatch=/^\/api\/documents\/(\d+)$/.exec(url.pathname);
  if (req.method==='GET' && documentMatch) { const row=db.prepare('SELECT d.*,c.case_number FROM generated_documents d JOIN cases c ON c.id=d.case_id WHERE d.id=?').get(Number(documentMatch[1])); if(!row||!authorizeCase(row.case_number,url.searchParams.get('token')))return json(res,403,{error:'Nav piekļuves dokumentam.'}); res.writeHead(200,{'content-type':'application/pdf','content-disposition':`attachment; filename="${row.case_number}-v${row.version}.pdf"`,'x-document-sha256':row.sha256}); fs.createReadStream(row.file_path).pipe(res); return; }
  if (req.method === 'GET' && url.pathname.startsWith('/api/cases/')) { const item=getPublicCase(decodeURIComponent(url.pathname.slice(11))); return item ? json(res,200,item) : json(res,404,{error:'Lieta nav atrasta.'}); }
  if (req.method === 'POST' && url.pathname === '/api/cases') {
    const match=/multipart\/form-data;\s*boundary=(?:"([^"]+)"|([^;]+))/i.exec(req.headers['content-type'] || '');
    if (!match) return json(res,415,{error:'Nepieciešams multipart/form-data.'});
    const parsed=parseMultipart(await body(req), match[1] || match[2]); const errors=validateCase(parsed.values);
    if (Object.keys(errors).length) return json(res,400,{error:'Pārbaudiet ievadītos datus.',fields:errors});
    fs.mkdirSync(config.uploadDir,{recursive:true}); const saved=[];
    try { if(parsed.files.length>5)throw Object.assign(new Error('Var pievienot ne vairāk kā piecus failus.'),{status:400});for (const file of parsed.files) { if (!file.originalName) continue; validateUpload(file);const storedName=`${crypto.randomUUID()}${path.extname(file.originalName).toLowerCase()}`; fs.writeFileSync(path.join(config.uploadDir,storedName),file.content,{flag:'wx',mode:0o600}); saved.push({...file,storedName,size:file.content.length}); } const result=createCase(parsed.values,saved); return json(res,201,{message:'Jūsu jautājums ir saņemts.',...result,applicationUrl:`/case.html?case=${encodeURIComponent(result.caseNumber)}#token=${result.accessToken}`,cabinetUrl:`/cabinet.html#token=${result.cabinetAccessToken}`}); }
    catch (error) { for (const file of saved) fs.rmSync(path.join(config.uploadDir,file.storedName),{force:true}); throw error; }
  }
  return false;
}
