import path from 'node:path';
import process from 'node:process';

export const config = Object.freeze({
  port: Number(process.env.PORT || 3000),
  databasePath: path.resolve(process.env.DATABASE_PATH || './data/platform.db'),
  uploadDir: path.resolve(process.env.UPLOAD_DIR || './uploads'),
  pdfDir: path.resolve(process.env.PDF_DIR || './data/pdfs'),
  pdfFontPath: path.resolve(process.env.PDF_FONT_PATH || 'C:/Windows/Fonts/arial.ttf'),
  signedDocumentDir: path.resolve(process.env.SIGNED_DOCUMENT_DIR || './data/signed'),
  publicBaseUrl: process.env.PUBLIC_BASE_URL || `http://localhost:${process.env.PORT || 3000}`,
  nodeEnv: process.env.NODE_ENV || 'development',
  signingProvider: process.env.SIGNING_PROVIDER || 'mock',
  signingApiEnabled: process.env.ENABLE_SIGNING_API === 'true',
  eparaksts: Object.freeze({
    portalBaseUrl: process.env.EPARAKSTS_PORTAL_BASE_URL || 'https://www.eparaksts.lv',
    username: process.env.EPARAKSTS_PORTAL_USERNAME || '',
    password: process.env.EPARAKSTS_PORTAL_PASSWORD || '',
    clientCertPath: process.env.EPARAKSTS_CLIENT_CERT_PATH || '',
    clientKeyPath: process.env.EPARAKSTS_CLIENT_KEY_PATH || ''
  }),
  maxUploadBytes: Number(process.env.MAX_UPLOAD_MB || 10) * 1024 * 1024,
  municipalityEmail: process.env.MUNICIPALITY_EMAIL || '',
  emailProvider: process.env.EMAIL_PROVIDER || 'mock',
  mailFrom: process.env.MAIL_FROM || '',
  allowMockDelivery: process.env.ALLOW_MOCK_DELIVERY === 'true',
  maxDeliveryAttempts: Number(process.env.MAX_DELIVERY_ATTEMPTS || 3),
  defaultResponseDueDays: process.env.DEFAULT_RESPONSE_DUE_DAYS ? Number(process.env.DEFAULT_RESPONSE_DUE_DAYS) : null,
  inboundWebhookSecret: process.env.INBOUND_WEBHOOK_SECRET || '',
  adminApiToken: process.env.ADMIN_API_TOKEN || '',
  searchProvider: process.env.SEARCH_PROVIDER || 'disabled',
  requireHttps: process.env.REQUIRE_HTTPS === 'true' || process.env.NODE_ENV === 'production',
  trustProxy: process.env.TRUST_PROXY === 'true',
  rateLimitWindowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 60000),
  rateLimitPublic: Number(process.env.RATE_LIMIT_PUBLIC || 30),
  rateLimitAuthenticated: Number(process.env.RATE_LIMIT_AUTHENTICATED || 120)
});
