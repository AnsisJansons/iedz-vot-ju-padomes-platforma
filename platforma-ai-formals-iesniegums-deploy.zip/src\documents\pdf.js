import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { PDFDocument, rgb } from 'pdf-lib';
import fontkit from '@pdf-lib/fontkit';
import { config } from '../config.js';
import { db } from '../db/index.js';
import { audit } from '../audit/service.js';

const pageWidth=595.28, pageHeight=841.89, margin=58, textWidth=pageWidth-margin*2;
function wrap(text,font,size,width=textWidth){const lines=[];for(const paragraph of String(text).split('\n')){if(!paragraph.trim()){lines.push('');continue;}let line='';for(const word of paragraph.trim().split(/\s+/)){const next=line?`${line} ${word}`:word;if(font.widthOfTextAtSize(next,size)>width&&line){lines.push(line);line=word;}else line=next;}if(line)lines.push(line);}return lines;}
function right(page,text,y,font,size){page.drawText(text,{x:pageWidth-margin-font.widthOfTextAtSize(text,size),y,size,font,color:rgb(.08,.16,.14)});}

export async function generatePdf(item){
  const version=db.prepare('SELECT * FROM application_versions WHERE case_id=? AND is_approved=1 ORDER BY version DESC LIMIT 1').get(item.id);
  if(!version||item.status!=='APPROVED')throw Object.assign(new Error('PDF var ģenerēt tikai apstiprinātai iesnieguma versijai.'),{status:409});
  const existing=db.prepare('SELECT * FROM generated_documents WHERE application_version_id=?').get(version.id);if(existing)return existing;
  if(!fs.existsSync(config.pdfFontPath))throw Object.assign(new Error('Nav atrasts PDF fonts. Pārbaudiet PDF_FONT_PATH.'),{status:500});
  const pdf=await PDFDocument.create();pdf.registerFontkit(fontkit);const font=await pdf.embedFont(fs.readFileSync(config.pdfFontPath),{subset:true}),bold=font;
  let page=pdf.addPage([pageWidth,pageHeight]),y=785;
  const newPage=()=>{page=pdf.addPage([pageWidth,pageHeight]);y=785;};
  const line=(text,{size=11,leading=18,fontFamily=font,indent=0}={})=>{for(const value of wrap(text,fontFamily,size,textWidth-indent)){if(y<72)newPage();page.drawText(value,{x:margin+indent,y,size,font:fontFamily,color:rgb(.08,.16,.14)});y-=leading;}};
  const recipient=['Limbažu novada pašvaldībai'];recipient.forEach(value=>{right(page,value,y,font,12);y-=20;});
  y-=54;
  const applicant=[`Iesniedzējs: ${item.first_name} ${item.last_name}`,`E-pasts: ${item.email}`];if(item.phone)applicant.push(`Tālrunis: ${item.phone}`);applicant.forEach(value=>{right(page,value,y,font,11);y-=17;});
  y-=62;
  const heading='IESNIEGUMS';page.drawText(heading,{x:(pageWidth-font.widthOfTextAtSize(heading,16))/2,y,size:16,font:bold,color:rgb(.08,.16,.14)});y-=50;
  line(version.content,{leading:19});
  const attachments=db.prepare('SELECT original_name FROM attachments WHERE case_id=? ORDER BY id').all(item.id);
  if(attachments.length){y-=10;line('Pielikumi:',{size:11,fontFamily:bold});attachments.forEach((attachment,index)=>line(`${index+1}. ${attachment.original_name}`,{leading:17}));}
  if(y<125)newPage();else y-=40;
  const today=new Date();
  const date=`${String(today.getDate()).padStart(2,'0')}.${String(today.getMonth()+1).padStart(2,'0')}.${today.getFullYear()}.`;
  const datePlace=item.residence?`${item.residence}, ${date}`:date;
  page.drawText(datePlace,{x:margin,y,size:11,font,color:rgb(.08,.16,.14)});right(page,`${item.first_name} ${item.last_name}`,y,font,11);
  const bytes=await pdf.save(),hash=crypto.createHash('sha256').update(bytes).digest('hex');fs.mkdirSync(config.pdfDir,{recursive:true});
  const docVersion=db.prepare('SELECT COALESCE(MAX(version),0)+1 AS value FROM generated_documents WHERE case_id=?').get(item.id).value;
  const filePath=path.join(config.pdfDir,`${item.case_number}-v${docVersion}.pdf`);fs.writeFileSync(filePath,bytes,{flag:'wx'});const now=new Date().toISOString();
  const result=db.prepare('INSERT INTO generated_documents(case_id,application_version_id,version,file_path,sha256,generated_at) VALUES(?,?,?,?,?,?)').run(item.id,version.id,docVersion,filePath,hash,now);
  db.prepare('UPDATE cases SET pdf_path=?,updated_at=? WHERE id=?').run(filePath,now,item.id);audit({caseId:item.id,action:'PDF_GENERATED',details:{documentVersion:docVersion,sha256:hash}});
  return {id:Number(result.lastInsertRowid),file_path:filePath,version:docVersion,sha256:hash,generated_at:now};
}
