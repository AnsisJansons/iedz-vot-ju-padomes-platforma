import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { config } from './config.js';
import { handleApi } from './api/router.js';
import { allowRequest, securityHeaders, safeRequestId } from './security/http.js';
import './db/index.js';

const publicDir=path.resolve('public');
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8'};
const server=http.createServer(async(req,res)=>{const requestId=safeRequestId();try{securityHeaders(res);res.setHeader('x-request-id',requestId);const isHttps=Boolean(req.socket.encrypted||(config.trustProxy&&req.headers['x-forwarded-proto']==='https'));if(config.requireHttps&&!isHttps){res.writeHead(426,{'content-type':'application/json; charset=utf-8'});return res.end(JSON.stringify({error:'Nepieciešams HTTPS savienojums.'}));}const limit=req.url?.startsWith('/api/')?config.rateLimitPublic:config.rateLimitAuthenticated;if(!allowRequest(req,{limit,windowMs:config.rateLimitWindowMs})){res.writeHead(429,{'content-type':'application/json; charset=utf-8','retry-after':String(Math.ceil(config.rateLimitWindowMs/1000))});return res.end(JSON.stringify({error:'Pārāk daudz pieprasījumu. Mēģiniet vēlāk.'}));}const url=new URL(req.url,'http://localhost');if(url.pathname.startsWith('/api/')){const handled=await handleApi(req,res,url);if(handled!==false)return;}const requested=url.pathname==='/'?'index.html':url.pathname.slice(1);const target=path.resolve(publicDir,requested);if(!target.startsWith(publicDir+path.sep)&&target!==path.join(publicDir,'index.html')){res.writeHead(403);return res.end();}fs.readFile(target,(err,data)=>{if(err){res.writeHead(404);res.end('Nav atrasts');}else{res.writeHead(200,{'content-type':mime[path.extname(target)]||'application/octet-stream','x-content-type-options':'nosniff'});res.end(data);}});}catch(error){console.error(JSON.stringify({requestId,status:error.status||500,code:error.code||'INTERNAL_ERROR'}));if(!res.headersSent){res.writeHead(error.status||500,{'content-type':'application/json; charset=utf-8'});res.end(JSON.stringify({error:error.status?error.message:'Servera kļūda.'}));}}});
server.listen(config.port,config.bindHost,()=>console.log(`Platforma darbojas portā ${config.port}`));
